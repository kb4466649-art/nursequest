// netlify/functions/send-notification.js
//
// Server-side proxy for sending OneSignal push notifications.
// The browser can't call OneSignal's REST API directly (OneSignal blocks
// cross-origin requests from browsers for this endpoint), so this function
// runs on Netlify's servers and forwards the request instead — no CORS
// restriction applies to server-to-server calls.
//
// The admin screen still stores/owns the OneSignal App ID + REST API Key
// (in Firestore, same trust model as the app's other shared API keys) and
// simply passes them to this function along with the notification payload.

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  let data;
  try {
    data = JSON.parse(event.body);
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { restKey, payload } = data;

  if (!restKey || !payload) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Missing restKey or payload' }),
    };
  }

  try {
    const resp = await fetch('https://onesignal.com/api/v1/notifications', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        Authorization: 'Basic ' + restKey,
      },
      body: JSON.stringify(payload),
    });

    const result = await resp.json();

    return {
      statusCode: resp.status,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result),
    };
  } catch (err) {
    return {
      statusCode: 502,
      body: JSON.stringify({ error: 'Failed to reach OneSignal', details: String(err) }),
    };
  }
};
